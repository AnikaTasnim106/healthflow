const express = require('express');
const router = express.Router();
const db = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');
router.get('/', requireAuth, requireRole('admin', 'receptionist', 'patient'), async (req, res, next) => {
  try {
    const { role, patient_id } = req.user;
    const onlyMine = role === 'patient';

    const result = await db.query(
      `SELECT b.bill_id, b.issue_date, b.total_amount, b.pay_status,
              p.name AS patient_name,
              COALESCE(SUM(pay.paid_amount), 0) AS amount_paid,
              b.total_amount - COALESCE(SUM(pay.paid_amount), 0) AS due
       FROM bill b
       JOIN patient p        ON b.patient_id = p.patient_id
       LEFT JOIN payment pay ON b.bill_id    = pay.bill_id
       WHERE ($1::int IS NULL OR b.patient_id = $1)
       GROUP BY b.bill_id, p.name
       ORDER BY b.issue_date DESC`,
      [onlyMine ? patient_id : null]
    );
    res.json(result.rows);
  } catch (err) { next(err); }
});
router.get('/due', requireAuth, requireRole('admin', 'receptionist'), async (req, res, next) => {
  try {
    const result = await db.query(
      `SELECT b.bill_id, b.issue_date, b.total_amount, b.pay_status,
              p.name AS patient_name, p.phone,
              b.total_amount - COALESCE(SUM(pay.paid_amount), 0) AS due_amount
       FROM bill b
       JOIN patient p        ON b.patient_id = p.patient_id
       LEFT JOIN payment pay ON b.bill_id    = pay.bill_id
       WHERE b.pay_status != 'Paid'
       GROUP BY b.bill_id, p.name, p.phone
       ORDER BY due_amount DESC`
    );
    res.json(result.rows);
  } catch (err) { next(err); }
});
router.get('/revenue', requireAuth, requireRole('admin', 'receptionist'), async (req, res, next) => {
  try {
    const result = await db.query(
      `SELECT TO_CHAR(issue_date, 'YYYY-MM') AS month,
              COUNT(*) AS bill_count,
              SUM(total_amount) AS total_revenue,
              SUM(total_amount) - COALESCE(SUM(paid.total_paid), 0) AS total_due
       FROM bill b
       LEFT JOIN (
           SELECT bill_id, SUM(paid_amount) AS total_paid
           FROM payment GROUP BY bill_id
       ) paid ON b.bill_id = paid.bill_id
       GROUP BY TO_CHAR(issue_date, 'YYYY-MM')
       ORDER BY month DESC`
    );
    res.json(result.rows);
  } catch (err) { next(err); }
});
router.post('/from-appointment/:id', requireAuth, requireRole('admin', 'receptionist'), async (req, res, next) => {
  try {
    const apptId = req.params.id;

    await db.query(`CALL sp_generate_opd_bill($1)`, [apptId]);

    const bill = await db.query(
      `SELECT b.bill_id, b.total_amount, b.pay_status, p.name AS patient_name
       FROM appointment a
       JOIN bill b ON b.patient_id = a.patient_id AND b.admission_id IS NULL
       JOIN patient p ON b.patient_id = p.patient_id
       WHERE a.appt_id = $1
       ORDER BY b.bill_id DESC
       LIMIT 1`,
      [apptId]
    );

    const items = bill.rows[0]
      ? await db.query(
          `SELECT item_no, description, amount FROM bill_item
           WHERE bill_id = $1 ORDER BY item_no`,
          [bill.rows[0].bill_id]
        )
      : { rows: [] };

    res.status(201).json({ ...bill.rows[0], items: items.rows });
  } catch (err) {
    const m = err.message || '';
    if (m.includes('not found'))            return res.status(404).json({ error: m });
    if (m.includes('already been billed'))  return res.status(409).json({ error: 'This visit has already been billed' });
    if (m.includes('inside an admission'))  return res.status(409).json({ error: 'This visit is billed with the admission' });
    if (m.includes('only a completed'))     return res.status(409).json({ error: 'Only a completed visit can be billed' });
    next(err);
  }
});

router.post('/from-admission/:id', requireAuth, requireRole('admin', 'receptionist'), async (req, res, next) => {
  try {
    const admissionId = req.params.id;

    const finalised = await db.query(
      `SELECT b.bill_id FROM bill b
       JOIN bill_item bi ON bi.bill_id = b.bill_id
       WHERE b.admission_id = $1 AND bi.description LIKE 'Room charge%'
       LIMIT 1`,
      [admissionId]
    );

    if (finalised.rows.length > 0) {
      return res.status(409).json({
        error: `This stay is already billed on B-${String(finalised.rows[0].bill_id).padStart(3, '0')}`
      });
    }

    const adm = await db.query(
      `SELECT discharge_date FROM admission WHERE admission_id = $1`,
      [admissionId]
    );

    if (adm.rows.length === 0) {
      return res.status(404).json({ error: 'Admission not found' });
    }

    if (adm.rows[0].discharge_date === null) {
      return res.status(409).json({
        error: 'Discharge the patient before generating the bill'
      });
    }

    await db.query(`CALL sp_generate_admission_bill($1)`, [admissionId]);

    const bill = await db.query(
      `SELECT b.*, p.name AS patient_name
       FROM bill b JOIN patient p ON b.patient_id = p.patient_id
       WHERE b.admission_id = $1
       ORDER BY b.bill_id DESC LIMIT 1`,
      [admissionId]
    );

    const items = await db.query(
      `SELECT item_no, description, amount FROM bill_item
       WHERE bill_id = $1 ORDER BY item_no`,
      [bill.rows[0].bill_id]
    );

    res.status(201).json({ ...bill.rows[0], items: items.rows });
  } catch (err) {
    if (err.message && err.message.includes('not found')) {
      return res.status(404).json({ error: err.message });
    }
    next(err);
  }
});
router.get('/:id', requireAuth, async (req, res, next) => {
  try {
    const { id } = req.params;

    const bill = await db.query(
      `SELECT b.*, p.name AS patient_name, p.phone
       FROM bill b JOIN patient p ON b.patient_id = p.patient_id
       WHERE b.bill_id = $1`, [id]
    );
    if (bill.rows.length === 0) {
      return res.status(404).json({ error: 'Bill not found' });
    }
    const { role, patient_id } = req.user;
    if (role === 'patient' && bill.rows[0].patient_id !== patient_id) {
      return res.status(403).json({ error: 'You can only access your own bills' });
    }

    const items = await db.query(
      `SELECT item_no, description, amount FROM bill_item
       WHERE bill_id = $1 ORDER BY item_no`, [id]);

    const payments = await db.query(
      `SELECT payment_id, pay_date, method, paid_amount FROM payment
       WHERE bill_id = $1 ORDER BY pay_date`, [id]);

    res.json({ ...bill.rows[0], items: items.rows, payments: payments.rows });
  } catch (err) { next(err); }
});
router.post('/', requireAuth, requireRole('admin', 'receptionist'), async (req, res, next) => {
  try {
    const { patient_id, admission_id, items } = req.body;

    if (!items || items.length === 0) {
      return res.status(400).json({ error: 'At least one bill item required' });
    }

    const bill = await db.withTransaction(async (client) => {
      const b = await client.query(
        `INSERT INTO bill (patient_id, admission_id, total_amount)
         VALUES ($1, $2, 0) RETURNING bill_id`,
        [patient_id, admission_id || null]
      );
      const billId = b.rows[0].bill_id;

      let itemNo = 1;
      for (const it of items) {
        await client.query(
          `INSERT INTO bill_item (bill_id, item_no, description, amount)
           VALUES ($1, $2, $3, $4)`,
          [billId, itemNo++, it.description, it.amount]
        );
      }

      const final = await client.query(
        `UPDATE bill SET total_amount =
           (SELECT SUM(amount) FROM bill_item WHERE bill_id = $1)
         WHERE bill_id = $1 RETURNING *`,
        [billId]
      );
      return final.rows[0];
    });

    res.status(201).json(bill);
  } catch (err) { next(err); }
});
router.post('/:id/payment', requireAuth, requireRole('admin', 'receptionist'), async (req, res, next) => {
  try {
    const { id } = req.params;
    const { method, paid_amount } = req.body;

    const amount = Number(paid_amount);
    if (!amount || amount <= 0) {
      return res.status(400).json({ error: 'Enter an amount above zero' });
    }

    const updatedBill = await db.withTransaction(async (client) => {
      const bill = await client.query(
        `SELECT b.bill_id, b.total_amount,
                COALESCE((SELECT SUM(paid_amount) FROM payment
                          WHERE bill_id = b.bill_id), 0) AS already_paid
         FROM bill b
         WHERE b.bill_id = $1
         FOR UPDATE`,
        [id]
      );

      if (bill.rows.length === 0) {
        throw { status: 404, message: 'Bill not found' };
      }

      const total = Number(bill.rows[0].total_amount);
      const paid  = Number(bill.rows[0].already_paid);
      const due   = total - paid;

      if (due <= 0) {
        throw { status: 409, message: 'This bill is already settled in full' };
      }

      if (amount > due) {
        throw {
          status: 409,
          message: `Only ${due.toLocaleString('en-IN')} is still due on this bill`
        };
      }

      await client.query(
        `INSERT INTO payment (bill_id, method, paid_amount)
         VALUES ($1, $2, $3)`,
        [id, method, amount]
      );

      const result = await client.query(
        `UPDATE bill b
         SET pay_status = CASE
             WHEN COALESCE((SELECT SUM(paid_amount) FROM payment WHERE bill_id = b.bill_id), 0) = 0
                  THEN 'Unpaid'
             WHEN COALESCE((SELECT SUM(paid_amount) FROM payment WHERE bill_id = b.bill_id), 0) >= b.total_amount
                  THEN 'Paid'
             ELSE 'Partial'
         END
         WHERE bill_id = $1
         RETURNING *`,
        [id]
      );

      if (result.rows.length === 0) {
        throw { status: 404, message: 'Bill not found' };
      }
      return result.rows[0];
    });

    res.status(201).json(updatedBill);
  } catch (err) {
    if (err.status) return res.status(err.status).json({ error: err.message });
    if (err.code === '23514') {
      return res.status(400).json({ error: 'Payment amount must be above zero' });
    }
    next(err);
  }
});

module.exports = router;